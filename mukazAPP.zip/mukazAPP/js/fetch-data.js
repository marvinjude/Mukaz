// $('document').ready(function(){
// 	$.post("../customer/ajax_customers_return.php",
// 	{
// 		name:"jude",
// 		phone:"090"

// 	},
// 	function(data,status){
// 		alert("Data: " + data + "\nStatus: " + status);
// 		console.log(data);
// 	});
// });

