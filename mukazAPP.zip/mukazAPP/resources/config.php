<?php

  return (object) array(
     "host"=> "localhost",
     "username"=> "dlcftasu_dlcf",
     "password" => "saveminaj.badguy123",
     "db" => "dlcftasu_nigeria"
  );


?>