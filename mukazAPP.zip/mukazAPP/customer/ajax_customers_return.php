<?php
  // header("Content-type: text/json");
echo $_POST['name'];
echo $_POST ['phone'];



?>